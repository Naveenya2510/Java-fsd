package projectp2;

public class implementbinarysearch {

	 public static int binarySearch(int[] arr, int target) {
		 
	        int start = 0;
	        int end = arr.length - 1;

	        while (start <= end) {
	            int mid = start + (end - start) / 2;

	            if (arr[mid] == target) {
	                return mid; 
	            } else if (arr[mid] < target) {
	                start = mid + 1; 
	            } else {
	                end = mid - 1; 
	            }
	        }
	        return -1; 
	    }

	    public static void main(String[] args) {
	    	
	        int[] arr = {99, 88, 55, 77, 66, 22};
	        int target = 55;

	        int in = binarySearch(arr, target);

	        if (in != -1) {
	            System.out.println("The index of the given element is " + in);
	        } else {
	            System.out.println("The given element is not found in the array ");
	        }

	    }
}
