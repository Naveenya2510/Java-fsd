package projecttopractice2;

import java.util.Arrays;

public class smallestnumberinfourthplace {

	public static void main(String[] args) {
		
		int[] unsortedList= {3,28,9,29,5,10,20};
		int SmallestFourthnumber=findsmallestinfourth(unsortedList);
		System.out.println("The smallest element in the Fourth place is: "+SmallestFourthnumber);
	}

public static int findsmallestinfourth(int[] arr) 
{
if(arr.length<4)	
{
	return -1;
}
Arrays.sort(arr);
return arr[3];
}
}