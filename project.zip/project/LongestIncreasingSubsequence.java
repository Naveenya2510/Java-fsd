package project;

	public class LongestIncreasingSubsequence {
	public static int lengthOfLongestIncreasingSubsequence(int [] arr) {
	int n = arr.length;
	if (arr==null || n==0) {
	return 0;
	}
	int[] arr1=new int[n];
	 for (int i = 0; i < n; i++) {
	 arr1[i] = 1;
	 }
	for(int j=1;j<n;j++) {
	for(int i=0;i<j;i++) {
	if(arr[j]>arr[i]) {
	arr1[j]=Math.max(arr1[j],arr1[i]+1);
	}
	}
	}
	int max=0;
	for(int i=0;i<n;i++) {
	max=Math.max(max, arr1[i]);
	}
	return max;
	}
	public static void main(String[] args) {
	// TODO Auto-generated method stub
	int q1[]= {15,6,3,34,24,22,03,2,98};
	int q3[]= {10,7, 2, 8, 3, 7, 103, 18, 54};
	int q2=lengthOfLongestIncreasingSubsequence(q3);
	System.out.println("Length of LongestIncreasing Subsequence is:"+q2);
	}
	}
