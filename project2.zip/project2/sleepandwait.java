package project2;

class A extends Thread{
	public void run() {
		synchronized (this) {
			System.out.println(Thread.currentThread().getName()+ " starts here");

			try {
				Thread.sleep(3520);
			}
			catch(InterruptedException e) {
				System.out.println(e);
			}
			System.out.println(Thread.currentThread().getName()+"done");
			notify();
		}
	}
}
public class sleepandwait {

	public static void main(String[] args) {

		A t1=new A();
		A t2=new A();

		t1.setName("A");
		t2.setName("B");

		t1.start();

		synchronized(t1) {
			try {
				System.out.println(Thread.currentThread().getName()+" Waiting for thread 1 to complete");
				t1.wait();
			}
			catch(InterruptedException e) {
				System.out.println(e);
			}

			System.out.println(Thread.currentThread().getName()+"done waiting");
		}
		t2.start();
	}

}