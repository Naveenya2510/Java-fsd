package project8;

public class encapsulation {

	private String brand;
	private String model;

	//Constructors
	public encapsulation(String brand, String model) {
        this.brand = brand;
        this.model = model;
        System.out.println(brand);
    }

	//Encapsulation
	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	public static void main(String[] args) {
		encapsulation car = new encapsulation("Dzire", "Alto");
		
	}

}
