package project8;

public class classimplementation {

	public static void main(String[] args) {

		System.out.println(" Class  Implemetation is class");
	}

}