package project8;

public class abstraction {


	public static void main(String[] args) {
		
		calculatorimplementation calculatorimplementation=new calculatorimplementation();
		calculatorimplementation.sub(45,35);
	}

}