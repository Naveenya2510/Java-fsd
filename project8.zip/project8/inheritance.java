package project8;

class amount{
	int amount=4000;
}


class bank extends amount{

	void calculateAmountWithROI(int amount,double roi) {

		double finalAmount=amount+amount*(roi/100);
		System.out.println(finalAmount);
	}

}

class hdfc extends bank {
	void calculateROI() {

		double roi=5.5;
		super.calculateAmountWithROI(amount,roi);
	}

}

class bob extends bank{
	void calculateROI() {

		double roi=9.5;
		super.calculateAmountWithROI(amount,roi);
	}
}

public class inheritance {


	public static void main(String[] args) {

		hdfc bank1=new hdfc();
		System.out.println("HDFC final amount is:");
		bank1.calculateROI();


		bob bank2=new bob();
		System.out.println("BOB final amount is:");
		bank2.calculateROI();
	}
}