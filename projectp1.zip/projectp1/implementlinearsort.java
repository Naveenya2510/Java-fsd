package projectp1;

public class implementlinearsort {

		static int[] arr = {99, 88, 55, 77, 66, 22};
	    static int target = 99;

	    public static void main(String[] args) {
	    	
	        int index = ls(arr, target);

	        if (index != -1) {
	            System.out.println("The index of the given element is " + index);
	        } else {
	            System.out.println("The given element is not found in the array");
	        }
	    }

	    public static int ls(int[] arr, int target) {
	    	
	        for (int x = 0; x < arr.length; x++) {
	            if (arr[x] == target) {
	                return x;
	            }
	        }
	        return -1; 
	    }
	}

