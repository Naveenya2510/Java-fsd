// Variable Declarations
var x = (2 * 3) + 5;
var y = 3 * 4;

// Function Definition
function calculateSumAndProduct(num1, num2) {
    var product = num1 * num2;
    var sum = num1 + num2;
    return product + sum;
}

// Function Calls and Console Output
var result1 = calculateSumAndProduct(2, 3);
console.log(result1);

console.log(calculateSumAndProduct(3, 4));

// Temperature Conversion Function and Output
function toCelsius(fahrenheit) {
    return (5 / 9) * (fahrenheit - 32);
}

console.log("The temperature is " + toCelsius(60));
