package assistedproject3c;

public class box {
			double volume(double length,double breadth,double height)
			{
				return length*breadth*height;
			}
	
	}

