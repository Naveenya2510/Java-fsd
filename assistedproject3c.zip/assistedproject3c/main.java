package assistedproject3c;

public class main {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
				box details=new box();
				double volume=details.volume(12,5,7);

				System.out.println("The Volume of box :"+volume);
			}

		}

	
