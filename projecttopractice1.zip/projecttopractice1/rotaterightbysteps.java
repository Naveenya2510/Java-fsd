package projecttopractice1;

public class rotaterightbysteps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = {9, 8, 6, 7, 5, 4, 2, 1, 3};
		int steps = 5;

		// Display of original array
		System.out.println("The given original array:");
		for (int num : arr) {
			System.out.print(num + " ");
		}

		// Right rotate 
		RotateRightArray(arr, steps);

		// Display of rotated
		System.out.println("\nThe given Array is Rotated as:");
		for (int num : arr) {
			System.out.print(num + " ");
	}

}
	public static void RotateRightArray(int[] arr, int steps) {
		int length = arr.length;
		
		int[] temp = new int[steps];

		for (int i = 0; i < steps; i++) {
			temp[i] = arr[length - steps + i]; 
		}
		// Shift the remaining elements to the right
		for (int i = length - 1; i >= steps; i--) {
			arr[i] = arr[i - steps];
		}

		// Copy the temporary array back to the original array
		for (int i = 0; i < steps; i++) {
			arr[i] = temp[i];
		}
	}
}