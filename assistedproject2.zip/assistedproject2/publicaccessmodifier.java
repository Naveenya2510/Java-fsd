package assistedproject2;

import practice_Project2_1.*;

public class publicaccessmodifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		publicFile pf=new publicFile();
		pf.display();
	}

}
