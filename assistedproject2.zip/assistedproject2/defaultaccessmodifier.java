package assistedproject2;

import practice_Project2_1.*;

public class defaultaccessmodifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DefaultFile df=new DefaultFile();
		df.display();
		
	}

}

