package assistedprojec;

import java.util.Scanner;

public class implicit {
	
	public void convert(int var) {
		double implicit= var;
		
		System.out.println("Convert from Integer to Double (Widening)-->"+implicit);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		implicit imp=new implicit();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter an Integer to convert: ");
		int variable=sc.nextInt();
		imp.convert(variable);
	}

}
