package project6;

public class eligibility {
	
	public void CheckScore(int score) throws InvalidScoreException {
		if(score>=50) {
			System.out.println("Congratulations !, You have Sucessfully cleared");
			
			
		}
		else {
			
			throw new InvalidScoreException();

		}

	}
}
