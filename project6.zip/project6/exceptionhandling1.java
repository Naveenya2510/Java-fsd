package project6;

public class exceptionHandling1 {
	public static void main(String[] args) throws InvalidScoreException {


		eligibility =new eligibility();
		eligibility.CheckScore(50);
	}

}