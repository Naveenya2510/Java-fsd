package project5;

class CustomException extends Exception{
	public CustomException(String Message) {
		super(Message);
	}
}

public class exceptionalhandling {

	public static void main(String[] args) {
//throw class
		try {
			int dividend=7;
			int divisor=0;
			
			if(divisor==0) {
				throw new ArithmeticException(" It Cannot divide by zero");
			}
			divideNumbers(dividend,divisor);
			
		//CustomException call
			int age=18;
			if(age<19) {
				throw new CustomException("Not eligible for driving license");
			}
			
			
		}
		catch(ArithmeticException e) {
			System.out.println("Arithmetic Exception" +e.getMessage());
		}
		
		catch(CustomException e) {
			System.out.println("Custom Exception"+e.getMessage());
		}
		finally {
			System.out.println("Block is executed");
		}
	}

	private static void divideNumbers(int dividend, int divisor) {
		if(divisor==0) {
			throw new ArithmeticException("It Cannot divide by zero");
		}
		int answer=dividend/divisor;
		System.out.println("Result of divide:"+answer);
	}

	
}