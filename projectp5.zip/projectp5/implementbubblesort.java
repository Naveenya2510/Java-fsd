package projectp5;

import java.util.Arrays;

public class implementbubblesort {
	// TODO Auto-generated method stub
	int[] array = {99, 88, 77, 6, 55, 44};
	{
        System.out.println("The given original array is" + Arrays.toString(array));
        bubbleSort(array);
        System.out.println("The sorted array is " + Arrays.toString(array));
	}
public static void bubbleSort(int[] array) {
    int n = array.length;
    boolean swapped;

    for (int i = 0; i < n - 1; i++) {
        swapped = false;

        for (int j = 0; j < n - 1 - i; j++) {
            if (array[j] > array[j + 1]) {
                // Swap array[j] and array[j + 1]
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;

                swapped = true;
            }
        }
        if (!swapped) {
            break;
        }
    }
}
}