package project4;

public class tryandcatch {
	
	public static void main(String[] args) {

		try {
			int num=9;
			int div=num/0;
			
			System.out.println("Result is:"+div);
		}
		
		catch(Exception e){
			e.printStackTrace();
			System.out.println("When a number divide by zero throws an Arithmetic Exception");
		}
		
		System.out.println("Due to Try-Catch block, Display after Exception");
	}

}