package projecttopractitce8;

import java.util.Stack;

public class inrestack {

		public static void main(String[] args) {
			// TODO Auto-generated method stub

			Stack<Integer> s1=new Stack<Integer>();
			
			//to push elements or inserting the elements into the stack
			s1.push(99);
			s1.push(88);
			s1.push(77);
			s1.push(66);
			s1.push(55);
			
			//to print the stack elements
			
			System.out.println("Insertion is sucessfully done:"+s1);
			
			//empty stack elements after deletion process is done
			while(!s1.empty()) {
				int popped=s1.pop();
				System.out.println("Element deleted after one by one"+popped);
			}

			System.out.println("Deletion of stack:"+s1);
	 
		}


}
