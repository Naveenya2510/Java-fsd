package assistedproject3d;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				box details=new box();

				details.length=3;
				details.breadth=5;
				details.height=7;
				double volume=details.volume();
				System.out.println("final salary is -->"+volume);
				}

		}


