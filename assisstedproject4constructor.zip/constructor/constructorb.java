package constructor;

public class constructorb {

			public static void main(String[] args) {
				// TODO Auto-generated method stub

				constructora vol=new constructora(20,30,40);
			}

		}


