package projectp3;

public class implementexponentialsearch {

	public static int exponentialSearch(int[] arr, int target) {
		
        if (arr[0] == target) {
            return 0; 
        }

        int bound = 1;
        int n = arr.length;

        while (bound < n && arr[bound] <= target) {
            bound *= 2; 
        }


        int left = bound / 2;
        int right = Math.min(bound, n - 1);

        return binarySearch(arr, target, left, right);
    }

    public static int binarySearch(int[] arr, int target, int left, int right) {
    	
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid; 
            } else if (arr[mid] < target) {
                left = mid + 1; 
            } else {
                right = mid - 1; 
            }
        }

        return -1; 
    }

    public static void main(String[] args) {
    	
        int[] arr = {99, 88, 55, 77, 66, 22};
        int target = 33;

        int index = exponentialSearch(arr, target);

        if (index != -1) {
            System.out.println("The index of the given element is" + index);
        } else {
            System.out.println("The given element is not found in the array");
        }
    }
}
