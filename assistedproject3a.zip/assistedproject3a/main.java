package assistedproject3a;

public class main {

			public static void main(String[] args) {
				box details=new box();
				details.volume(20,30,40);

			}


		}

