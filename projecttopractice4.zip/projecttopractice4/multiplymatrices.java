package projecttopractice4;

import java.util.*;

public class multiplymatrices {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        
        // Input the dim for the first matrix
        System.out.print("Enter number of rows that to be inserted in the first matrix: ");
        int rowsA = scanner.nextInt();
        System.out.print("Enter number of columns that to be inserted in the first matrix: ");
        int colsA = scanner.nextInt();

        // Input the dim for the second matrix
        System.out.print("Enter number of rows that to be inserted in the second matrix: ");
        int rowsB = scanner.nextInt();
        System.out.print("Enter number of columns that to be inserted in the second matrix: ");
        int colsB = scanner.nextInt();

        if (colsA != rowsB) {
            System.out.println("Multiplication of the matrix is not possible for the given Columns of the first matrix must be equal to the rows of the second matrix.");
            return;
        }

        // Initialization of the matrix
        int[][] matrixA = new int[rowsA][colsA];
        int[][] matrixB = new int[rowsB][colsB];
        int[][] resultMatrix = new int[rowsA][colsB];

        // Input for the first matrix
        System.out.println("Enter elements for the first matrix:");
        for (int i = 0; i < rowsA; i++) 
        {
            for (int j = 0; j < colsA; j++) 
            {
                matrixA[i][j] = scanner.nextInt();
            }
        }

        // Input for the second matrix
        System.out.println("Enter elements for the second matrix:");
        for (int i = 0; i < rowsB; i++) 
        {
            for (int j = 0; j < colsB; j++) 
            {
                matrixB[i][j] = scanner.nextInt();
            }
        }
        
        // Performing matrix multiplication
        for (int i = 0; i < rowsA; i++) 
        {
            for (int j = 0; j < colsB; j++)
            {
                for (int k = 0; k < colsA; k++) 
                {
                    resultMatrix[i][j] = resultMatrix[i][j] +matrixA[i][k] * matrixB[k][j];
                }
            }
        }

        // Display the result of matrix
        System.out.println("This is the result for the given matrix multiplication:");
        for (int i = 0; i < rowsA; i++) 
        {
            for (int j = 0; j < colsB; j++) 
            {
                System.out.print(resultMatrix[i][j] + " ");
            }
            System.out.println();
        }
	}
}
