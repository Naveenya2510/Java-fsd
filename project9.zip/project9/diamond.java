package project9;
interface A
{
		default void pluto() {

			System.out.println("Hi all i am earth");
		}
	}

interface B{
		default void pluto() {

			System.out.println("I am far away from the earth");

		}
	}

	class C implements A,B{
		public void pluto() {
			B.super.pluto();
		}

	}

	public class diamond {

		public static void main(String[] args) {

			C obj=new C();
			obj.pluto();
		}

	}