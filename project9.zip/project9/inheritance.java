

public class inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package project9;

class amount{
	int amount=6000;
}


class bank extends amount{

	void calculateAmountWithROI(int amount,double roi) {

		double finalAmount=amount+amount*(roi/100);
		System.out.println(finalAmount);
	}

}

class hdfc extends bank {
	void calculateROI() {

		double roi=5.5;
		super.calculateAmountWithROI(amount,roi);
	}

}

class icici extends bank{
	void calculateROI() {

		double roi=9.5;
		super.calculateAmountWithROI(amount,roi);
	}
}

public class InheritanceImplementation {

	public static void main(String[] args) {

		icici bank1=new icici();
		System.out.println("BOB final amount is:");
		bank1.calculateROI();


		hdfc bank2=new hdfc();
		System.out.println("IOB final amount is:");
		bank2.calculateROI();
	}
}