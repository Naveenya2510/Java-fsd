package assistedproject3b;

public class box {

	
		double length,breadth, height;
			void volume() 
			{
				double volume=length*breadth*height;
				System.out.println("The volume of the box is:"+volume);


		
	}

}
