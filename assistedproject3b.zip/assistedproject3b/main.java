package assistedproject3b;

public class main {
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

		box details=new box();
		details.length=10;
		details.height=20;
		details.breadth=30;
		details.volume();
	}
}


