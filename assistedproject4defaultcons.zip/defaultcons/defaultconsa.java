package defaultcons;

public class defaultconsa {
	
		defaultconsa(){
			double length=20;
			double breadth=30;
			double height=40;
			
			double volume=length*breadth*height;
			System.out.println("the volume of defaultconsa: "+volume);
		}

	}



