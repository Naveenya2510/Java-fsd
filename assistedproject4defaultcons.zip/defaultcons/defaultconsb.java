package defaultcons;

public class defaultconsb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				defaultconsa vol=new defaultconsa();
}

}
