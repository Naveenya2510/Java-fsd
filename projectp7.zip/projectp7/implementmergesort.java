package projectp7;

import java.util.Arrays;

public class implementmergesort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = {99, 88, 66, 22, 44, 7, 33, 199};
        
        System.out.println("The given original array is " + Arrays.toString(array));
        
        mergeSort(array);
        
        System.out.println("The sorted array is" + Arrays.toString(array));
    }

    public static void mergeSort(int[] array) {
        if (array.length <= 1) {
            return; // Already sorted
        }

        // Split the array into two halves
        int middle = array.length / 2;
        int[] left = Arrays.copyOfRange(array, 0, middle);
        int[] right = Arrays.copyOfRange(array, middle, array.length);

        // Recursively sort each half
        mergeSort(left);
        mergeSort(right);

        // Merge the sorted halves
        merge(array, left, right);
    }

    public static void merge(int[] array, int[] left, int[] right) {
        int i = 0;
        int j = 0; 
        int k = 0; 

        while (i < left.length && j < right.length) {
            if (left[i] <= right[j]) {
                array[k] = left[i];
                i++;
            } else {
                array[k] = right[j];
                j++;
            }
            k++;
        }

        while (i < left.length) {
            array[k] = left[i];
            i++;
            k++;
        }

        while (j < right.length) {
            array[k] = right[j];
            j++;
            k++;
        }

	}

}
