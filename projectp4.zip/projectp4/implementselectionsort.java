package projectp4;

import java.util.Arrays;

public class implementselectionsort {
	
	public static void selectionSort(int[] abi) {
		
        int n = abi.length;

        for (int i = 0; i < n-1; i++) {
            int minIndex = i;

         
            for (int j = i + 1; j < n; j++) {
                if (abi[j] < abi[minIndex]) {
                    minIndex = j;
                }
            }

            int temp = abi[i];
            abi[i] = abi[minIndex];
            abi[minIndex] = temp;
        }
    }

    public static void main(String[] args) {
    	
        int[] abi = {99, 88, 77, 6, 55, 44};
        System.out.println("The given original array is " + Arrays.toString(abi));

        selectionSort(abi);

        System.out.println("The sorted array is " + Arrays.toString(abi));
    }
}