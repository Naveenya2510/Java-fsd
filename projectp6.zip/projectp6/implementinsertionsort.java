package projectp6;

import java.util.Arrays;

public class implementinsertionsort {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] array = {99, 88, 77, 55, 22, 12, 8, 33, 7};
	        
	        System.out.println("The given original array is " + Arrays.toString(array));
	        
	        insertionSort(array);
	        
	        System.out.println("The sorted array is " + Arrays.toString(array));
	    }

	    public static void insertionSort(int[] array) {
	        int n = array.length;

	        for (int i = 1; i < n; i++) {
	            int key = array[i];
	            int j = i - 1;

	            
	            while (j >= 0 && array[j] > key) {
	                array[j + 1] = array[j];
	                j--;
	            }

	            array[j + 1] = key;
	        }
	    }
}
