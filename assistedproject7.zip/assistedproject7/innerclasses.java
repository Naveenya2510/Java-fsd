package assistedproject7;

public class innerclasses {

	public class india{

		private int NoOfmembersinparliment=29;


		public class tamilnadu{
			private int NoOfmembersinTn=15;

			public void displayNoOfmembersinparliment() {
				System.out.println("The Numbers of members in TamilNadu: "+NoOfmembersinTn);



			}
		}

		public void displayNoOfmembersinparlimen() {
			System.out.println("The No of members in India: "+NoOfmembersinparliment);
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		innerclasses innerclass=new innerclasses();
		innerclasses.india outer=innerclass.new india();
		innerclasses.india.tamilnadu inner=outer.new tamilnadu();
		outer.displayNoOfmembersinparlimen();
		inner.displayNoOfmembersinparliment();
	}

}

