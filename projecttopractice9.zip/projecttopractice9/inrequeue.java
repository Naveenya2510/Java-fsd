package projecttopractice9;

import java.util.LinkedList;

import java.util.Queue;

public class inrequeue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				Queue<Integer> qu =new LinkedList<>();
				
				qu.offer(99);
				qu.offer(88);
				qu.add(77);
				qu.add(66);
				qu.add(55);				
				
				System.out.println("After the insertion of Queue with elements");
				System.out.println(qu);
				
				while (!qu.isEmpty()) {
		            int dq = qu.poll();
		            System.out.println("Dequeue: " + dq);
		        }

				System.out.println("After the removal of the Queue elements:");
		        System.out.println(qu);
			}
}

